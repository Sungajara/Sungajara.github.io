function saludo() {
    var n = document.getElementById("nombre").value;
    alert("Hola "+n)

}


